//// sample to explore watson pa and compeare result simulating car selection from møllergruppen
'use strict';

var express = require('express'),
  app = express(),
  bluemix = require('./config/bluemix'),
  watson = require('watson-developer-cloud'),
  extend = require('util')._extend,
  Twit = require('twit');
var request = require('request');
var googleTranslate = require('google-translate')('<add your google key>');
// Espens var's
var resarray = [];
var cars;
var user;


// Bootstrap application settings
require('./config/express')(app);

// if bluemix credentials exists, then override local
var credentials = extend({
    version: 'v2',
    url: '<add your watson personal insights creds..>',
    username: '<add your watson personal insights creds..>',
    password: '<add your watson personal insights creds..>'
}, bluemix.getServiceCreds('personality_insights')); // VCAP_SERVICES

// Twitter connection variables
var tweet = new Twit({
    consumer_key: '<add your twitter keys>',
    consumer_secret: '<add your twitter keys>',
    access_token: '<add your twitter keys>',
    access_token_secret: '<add your twitter keys>'
});

// Create the service wrapper
var personalityInsights = new watson.personality_insights(credentials);

// Render the Index page
app.get('/', function(req, res) {
  res.render('index');
});

// Ajax post for Twitter and Watson
app.post('/tweetInsights', function(req, res) {
    var query = req.body.id;
    var options;
    var tpath;
    var tpush;

    console.log("Got request for tweets");

    if(query.charAt(0)==='@'){
    	console.log("Handle to query is: " + query);

    	options = {
        screen_name: query,
        count: 200,
        include_rts: false
        };

        tpath = 'statuses/user_timeline';

    }
    else {
    	console.log("Term to query is: " + query);

    	options = {
        q: query,
        lang: 'en',
        count: 300,
        };

        tpath = 'search/tweets';

    }

    var tweets = [];
    var transtweet = [];
    var insightsData;

    // Send a get to the Twitter API to retrieve a specifice user's timeline
    tweet.get(tpath, options, function(err, data) {

        if (err) {
            console.log(err);
        }

        if(query.charAt(0)==='@'){

        	// Loop through and add tweets to an array
        	for (var i = 0; i < data.length; i++) {
        		tweets.push(data[i].text);
        		}

        } else {

        	// Loop through and add tweets to an array
        	for (var i = 0; i<data.statuses.length; i++){
        		tweets.push(data.statuses[i].text);
        	}
        }
        googleTranslate.translate(tweets, 'no', 'en', function(err, translations) {
          if(err){
            console.log("translate error " +err);
            return;
          }else{
          for (var i =0; i<translations.length; i++){
            transtweet.push(translations[i].translatedText);
          //  console.log("translatedText" + transtweet);
        //  insightsData = transtweet.join(' ');
          }
        //  console.log(translations);
      }
          // =>  [{ translatedText: 'Hallo', originalText: 'Hello' }, ...]


      //  var insightsData = transtweet.join(' ');
      var data = transtweet;
      //  console.log("Returning tweets", data);
        console.log("Request received for Personality Insights...");
});
        personalityInsights.profile({
            text: data
        }, function(err, profile) {
            if (err) {
                console.log('error:', err);
                return res.json({t: err, p: err});
            } else {
            	console.log("Personality acquired.")
              //  console.log(JSON.stringify(profile, null, 2));
              //  console.log(tweets);
              // call the car database and start get the match on car...
            //  startMoller(profile);
              var getCars = function(callback){
              var url = '<add your cloudant url>/<add your db name>/_all_docs?include_docs=true';
                request({
                  url: url,
                  json: true },
                  function (error, response, body) {
                  if (!error && response.statusCode == 200) {
                    callback(null,body);
                  } else {
                    callback(error);
                  }
                })
              }
              getCars(function(err, result){
                console.log("getcars running!");
                  if(err){
                    console.log("Error " + JSON.stringfy(err));
                  } else {
                  //  console.log(result);
                  //  console.log("user: "+ profile.tree.children[0].id);
                    //console.log("user:" + user.id);
                    resarray=[];
                   result.rows.forEach(function(item) {
                   //console.log("detter er item: "+item.doc.insights.id);
                   similar(profile.tree, item.doc);
                    });
                    console.log("all done : " + resarray.length);
                    resarray.sort(function(a,b){return b.Score - a.Score});
                  //  console.log("::" + JSON.stringify(resarray));
                  }
                });
              function similar (origin,target) {
                origin = typeof(origin) === 'string' ? JSON.parse(origin) : origin;
                target = typeof(target) === 'string' ? JSON.parse(target) : target;
                var distance = 0.0,
                  origin_traits = origin.children[0].children[0].children,
                  target_traits = target.insights.children[0].children[0].children;
                  //console.log("user:" + origin.length);
                  //console.log("car:" + target_traits.length);
                  // for each trait in origin personality...
                origin_traits.forEach(function(trait, i) {
                //    console.log("used categories: " + trait.name+":"+trait.percentage);
                  distance += Math.pow(trait.percentage - target_traits[i].percentage, 2);
                });
                var ret = 1 - (Math.sqrt(distance / origin_traits.length));
                var payload = {"Score":ret.toFixed(4),"Merke": target.insights.name,"Model":target.insights.id,"DocId":target._id};
                resarray.push(payload);
                //node.send(msg);
                //console.log("similar done..");
                return resarray;

              }
              // end carstuff
                return res.json({
                    t: transtweet,
                    p: profile,
                    c: resarray
                });
            }
        }); // End personalityinsights.profile
    }); // End tweet.get
}); // End app.post

var port = process.env.VCAP_APP_PORT || 3000;
app.listen(port);
console.log('listening at:', port);
